weather-nw
==========
desktop weather by node-webkit
